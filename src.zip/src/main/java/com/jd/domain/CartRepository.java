package com.jd.domain;

import org.springframework.data.repository.CrudRepository;

public interface CartRepository extends CrudRepository<Cart1, Integer> {

}