package com.jd.domain;

import org.springframework.data.repository.CrudRepository;

public interface StudentRespository extends CrudRepository<Items1, Integer> {

}